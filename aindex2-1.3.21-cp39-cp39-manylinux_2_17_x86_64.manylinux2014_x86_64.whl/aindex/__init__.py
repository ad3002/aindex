# aindex/__init__.py
from .core.aindex import AIndex

__version__ = '1.3.21'
__all__ = ['AIndex']