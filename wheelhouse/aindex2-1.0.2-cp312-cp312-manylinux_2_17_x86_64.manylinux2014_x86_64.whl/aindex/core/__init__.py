# aindex/core/__init__.py
from .aindex import *